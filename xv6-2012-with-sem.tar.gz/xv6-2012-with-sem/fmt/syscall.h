3200 // System call numbers
3201 #define SYS_fork    1
3202 #define SYS_exit    2
3203 #define SYS_wait    3
3204 #define SYS_pipe    4
3205 #define SYS_read    5
3206 #define SYS_kill    6
3207 #define SYS_exec    7
3208 #define SYS_fstat   8
3209 #define SYS_chdir   9
3210 #define SYS_dup    10
3211 #define SYS_getpid 11
3212 #define SYS_sbrk   12
3213 #define SYS_sleep  13
3214 #define SYS_uptime 14
3215 
3216 #define SYS_open   15
3217 #define SYS_write  16
3218 #define SYS_mknod  17
3219 #define SYS_unlink 18
3220 #define SYS_link   19
3221 #define SYS_mkdir  20
3222 #define SYS_close  21
3223 
3224 
3225 
3226 
3227 
3228 
3229 
3230 
3231 
3232 
3233 
3234 
3235 
3236 
3237 
3238 
3239 
3240 
3241 
3242 
3243 
3244 
3245 
3246 
3247 
3248 
3249 
