var trap_8c =
[
    [ "idtinit", "trap_8c.html#a9b6e7f6c302700cb54216ad22cbc1591", null ],
    [ "trap", "trap_8c.html#a372d166e36c086c91e5f5d81e5fead3a", null ],
    [ "tvinit", "trap_8c.html#a9e7167b8e20e217c4af4e757f612ba6a", null ],
    [ "idt", "trap_8c.html#a3facbc1e1e6618fb238fc124bd9aa827", null ],
    [ "ticks", "trap_8c.html#a7fcd6915876e066781399d7b00f1b1f0", null ],
    [ "tickslock", "trap_8c.html#a094a4703b62095e2fa469fab3ffea5c7", null ],
    [ "vectors", "trap_8c.html#a3e6e0e8b5ba8014e09de2d9aa3740486", null ]
];