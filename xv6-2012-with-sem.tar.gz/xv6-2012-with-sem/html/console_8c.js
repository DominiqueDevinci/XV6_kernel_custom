var console_8c =
[
    [ "BACKSPACE", "console_8c.html#a629568514359445d2fbda71d70eeb1ce", null ],
    [ "C", "console_8c.html#ac54ae397901fe700628cafadea3c5208", null ],
    [ "CRTPORT", "console_8c.html#a2e3959df0a0c54f50f20d4776b14487f", null ],
    [ "INPUT_BUF", "console_8c.html#a5d85434f2a29f6c3048aeac34d0ce41d", null ],
    [ "consoleinit", "console_8c.html#ab508ff0f4db26fe35cd25fa648f9ee75", null ],
    [ "consoleintr", "console_8c.html#aad3d6ca39f23bb6d2686d2967e415193", null ],
    [ "consoleread", "console_8c.html#a28ac85a90987662e306ca8efbfe16074", null ],
    [ "consolewrite", "console_8c.html#a6af7eb39268127d389792cec37785666", null ],
    [ "cprintf", "console_8c.html#a90f0742d846503e4ed1804f1df421ec6", null ],
    [ "panic", "console_8c.html#a95c0aca5d6d7487933984f08b189917a", null ],
    [ "buf", "console_8c.html#aa427837782b05b05204809dfba33c8f5", null ],
    [ "e", "console_8c.html#ab56fa7c992b725d84916b987c3d532ea", null ],
    [ "input", "console_8c.html#a41db130acd332cdb95756628cfb2e48b", null ],
    [ "lock", "console_8c.html#ab28e82cd5dda7d960095706a3ea20572", null ],
    [ "locking", "console_8c.html#ae51110da3bc13ef49e32d1e2cda5d55c", null ],
    [ "r", "console_8c.html#af10fa12dd785c91e29528fbdc50cf9af", null ],
    [ "w", "console_8c.html#afdeff54db9a334718662b709641fdfe1", null ]
];