var elf_8h =
[
    [ "elfhdr", "structelfhdr.html", "structelfhdr" ],
    [ "proghdr", "structproghdr.html", "structproghdr" ],
    [ "ELF_MAGIC", "elf_8h.html#abb1c2e5626667aacc7b3efd269a6c0eb", null ],
    [ "ELF_PROG_FLAG_EXEC", "elf_8h.html#ac9608330ae745d90d7b59374fe827538", null ],
    [ "ELF_PROG_FLAG_READ", "elf_8h.html#a63df5e8bbab03913953e0042936f32c6", null ],
    [ "ELF_PROG_FLAG_WRITE", "elf_8h.html#a18b2debb63e51b9f66a702e3625a8622", null ],
    [ "ELF_PROG_LOAD", "elf_8h.html#a6a45c035b7a2930e62ac97a6bd8121e9", null ]
];