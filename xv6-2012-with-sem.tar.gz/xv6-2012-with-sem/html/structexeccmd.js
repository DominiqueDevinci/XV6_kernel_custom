var structexeccmd =
[
    [ "argv", "structexeccmd.html#aa5d608d354aee96f33c2fdca9a819305", null ],
    [ "eargv", "structexeccmd.html#aba17a3c518eb2ffd68f0219cc8c1792b", null ],
    [ "type", "structexeccmd.html#ac765329451135abec74c45e1897abf26", null ]
];