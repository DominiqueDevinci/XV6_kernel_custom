var kalloc_8c =
[
    [ "run", "structrun.html", "structrun" ],
    [ "freerange", "kalloc_8c.html#adeb1e621acdd949dffd5a054a43d1d89", null ],
    [ "kalloc", "kalloc_8c.html#a3af104ba40b66dcec8363ac5a70907ed", null ],
    [ "kfree", "kalloc_8c.html#aced59ecf8411235f6dffc065236711a5", null ],
    [ "kinit1", "kalloc_8c.html#a596c07f040e83fd8ea1857f36ffab4fb", null ],
    [ "kinit2", "kalloc_8c.html#a8efe9094969255a41fbdaaee820bd478", null ],
    [ "end", "kalloc_8c.html#af4f810c521bcfd87215d3007005a8325", null ],
    [ "freelist", "kalloc_8c.html#a25f1f0e27ad1cafebbde0b8b7455afb4", null ],
    [ "kmem", "kalloc_8c.html#a2954ba14fcdb793e2e0ca451af37607f", null ],
    [ "lock", "kalloc_8c.html#ab28e82cd5dda7d960095706a3ea20572", null ],
    [ "use_lock", "kalloc_8c.html#a37d4eb2590728645fea0e2da2b94e210", null ]
];