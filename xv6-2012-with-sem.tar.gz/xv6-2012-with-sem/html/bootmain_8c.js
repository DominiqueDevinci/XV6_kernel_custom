var bootmain_8c =
[
    [ "SECTSIZE", "bootmain_8c.html#af69dd8b281718a66b3e7a65250d24419", null ],
    [ "bootmain", "bootmain_8c.html#a0d198d492591e1b70a8a12109408a7e4", null ],
    [ "readsect", "bootmain_8c.html#ae7ef59ffa082283b72c54e43b7a16351", null ],
    [ "readseg", "bootmain_8c.html#af8097ce47ae21ccad1b0afd6f48ef62c", null ],
    [ "waitdisk", "bootmain_8c.html#a63222d4a07c38c198de5bd116a001935", null ]
];