var ioapic_8c =
[
    [ "ioapic", "structioapic.html", "structioapic" ],
    [ "INT_ACTIVELOW", "ioapic_8c.html#a516778548109f98ff313d8753d030d37", null ],
    [ "INT_DISABLED", "ioapic_8c.html#ab26e186261a82b907e024126fafbff1f", null ],
    [ "INT_LEVEL", "ioapic_8c.html#aed01298d37e73ed9737c8a6b70e67caa", null ],
    [ "INT_LOGICAL", "ioapic_8c.html#a7e41b4c95cc235d58d7a45411541f9de", null ],
    [ "IOAPIC", "ioapic_8c.html#a7d40119d2e49f7d8ae65520ccad99a1e", null ],
    [ "REG_ID", "ioapic_8c.html#a91339a8293cb53b81407c016bc41e2b1", null ],
    [ "REG_TABLE", "ioapic_8c.html#ad31b206e97e5e8cc5c70f8713669b27f", null ],
    [ "REG_VER", "ioapic_8c.html#ac56cc95ec46071699b119b24d6d808f9", null ],
    [ "ioapicenable", "ioapic_8c.html#a9688537a0879e9e2ac5a90184e2ef987", null ],
    [ "ioapicinit", "ioapic_8c.html#abce023b98422f397abdb425b20c8ceec", null ],
    [ "ioapic", "ioapic_8c.html#a61d7da24dba0ce35323deb8bb6cf6f91", null ]
];