var structbuf =
[
    [ "data", "structbuf.html#aa6cf955e5b0bdedd2b7d1461838a1134", null ],
    [ "dev", "structbuf.html#aaf61a1db4c34c23857104abc633d8ee6", null ],
    [ "flags", "structbuf.html#ac8bf36fe0577cba66bccda3a6f7e80a4", null ],
    [ "next", "structbuf.html#a5a609449f1b0b08ae96fe8b29e866fd7", null ],
    [ "prev", "structbuf.html#a48c008b4a22859e25eb05af3b5c22d45", null ],
    [ "qnext", "structbuf.html#a479532a4750e78d1ad819ef4121f6def", null ],
    [ "sector", "structbuf.html#ac4ea84582da27724e7735325dd490a92", null ]
];