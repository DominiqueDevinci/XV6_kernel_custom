var mp_8c =
[
    [ "mpbcpu", "mp_8c.html#a0685a063c0d98b393f61e6c2cb5cdcba", null ],
    [ "mpinit", "mp_8c.html#a2fd0b66a17c5347541448ef906b7b2a2", null ],
    [ "cpus", "mp_8c.html#a6d2633e73724907b582dfe6938ed7bb9", null ],
    [ "ioapicid", "mp_8c.html#a619ae379337e3cb2397ee0b6b4fd8d6b", null ],
    [ "ismp", "mp_8c.html#a46b52bd30030451d1b65291b77ba05d5", null ],
    [ "ncpu", "mp_8c.html#a6201a0661c3d5b88df5f63529298eb48", null ]
];