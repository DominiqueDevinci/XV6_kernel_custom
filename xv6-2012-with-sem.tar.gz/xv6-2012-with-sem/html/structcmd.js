var structcmd =
[
    [ "type", "structcmd.html#ac765329451135abec74c45e1897abf26", null ]
];