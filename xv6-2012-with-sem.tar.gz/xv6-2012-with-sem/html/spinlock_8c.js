var spinlock_8c =
[
    [ "acquire", "spinlock_8c.html#aed377f16a085b00de3a4b32392adbdfb", null ],
    [ "getcallerpcs", "spinlock_8c.html#a6ac35304ea80f01086b47edcc2328010", null ],
    [ "holding", "spinlock_8c.html#aea48df3e5cfb903179ad3dc78ab502d9", null ],
    [ "initlock", "spinlock_8c.html#abda07b4a007b2e888d9d783920460b89", null ],
    [ "popcli", "spinlock_8c.html#ae3424f669269fef400ce29c3aeb43fdb", null ],
    [ "pushcli", "spinlock_8c.html#a206b749d1b7768dadce61cbcde7e0f1c", null ],
    [ "release", "spinlock_8c.html#a1cee376aa9a00e754bf5481cd5f3d97b", null ]
];