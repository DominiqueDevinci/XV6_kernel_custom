var fs_8h =
[
    [ "superblock", "structsuperblock.html", "structsuperblock" ],
    [ "dinode", "structdinode.html", "structdinode" ],
    [ "dirent", "structdirent.html", "structdirent" ],
    [ "BBLOCK", "fs_8h.html#a3a09a26794f37ae657225b8f4444f368", null ],
    [ "BPB", "fs_8h.html#a3c88fd21abb83ef11461ce750c466828", null ],
    [ "BSIZE", "fs_8h.html#a403cf3149c084cea115b85c90721039a", null ],
    [ "DIRSIZ", "fs_8h.html#a48246fb9e5cb7f6a71ebc9ebc2f06562", null ],
    [ "IBLOCK", "fs_8h.html#ab114c389e176f9583562c70112425a44", null ],
    [ "IPB", "fs_8h.html#aadb6c866a6d0a173f5f0a6ed9c7e0228", null ],
    [ "MAXFILE", "fs_8h.html#a714b2485a6dd312e37226e1f833728a9", null ],
    [ "NDIRECT", "fs_8h.html#acd38e9532d4b3623f844b93c012a8e06", null ],
    [ "NINDIRECT", "fs_8h.html#a6d24f098ea2928d61ff80b123d761715", null ],
    [ "ROOTINO", "fs_8h.html#a22c8ea96d09283ed6496347806cc72a0", null ]
];