var structproc =
[
    [ "chan", "structproc.html#ae26528bc7e93e1eb8573a30309dc1424", null ],
    [ "context", "structproc.html#a30183e0aad45d3a56e1a22d3a8fecb17", null ],
    [ "cwd", "structproc.html#a9dfc3cbb1d3bc4f1b196c07092aa64ec", null ],
    [ "killed", "structproc.html#ab41bdc92598ccb9a0a7c2f177aa3bd5d", null ],
    [ "kstack", "structproc.html#ac9e6d1f1429b69e5e860320d95a3c5aa", null ],
    [ "name", "structproc.html#acd328517a6cf718155c2e6e22b671ca9", null ],
    [ "ofile", "structproc.html#a86c51eb2e4daa425944e034bfad64fb8", null ],
    [ "parent", "structproc.html#ad3a4594e539894e96ae2f8fea321fef2", null ],
    [ "pgdir", "structproc.html#abff3d102541220b0e98884d1fe2a6379", null ],
    [ "pid", "structproc.html#a7b6cb9255530f2807765ad74872ebdc5", null ],
    [ "state", "structproc.html#a59425505202fc7e53a519d95707cb26b", null ],
    [ "sz", "structproc.html#aad1b9173bbedb8de751a61a0864dcb3b", null ],
    [ "tf", "structproc.html#a5a8b7d6a32569e70bff92059bd93e602", null ]
];