var main_8c =
[
    [ "__attribute__", "main_8c.html#a08f0b7c20a38fda2383d4f70bb78dc3e", null ],
    [ "entrypgdir", "main_8c.html#af70a0e2fc2c22139673a8bd47319d5ff", null ]
];