var structpipe =
[
    [ "data", "structpipe.html#a4b9a650598bf6f6eff13ff36793ec4f4", null ],
    [ "lock", "structpipe.html#ab28e82cd5dda7d960095706a3ea20572", null ],
    [ "nread", "structpipe.html#a0e346df9e608d0a7d2c8538f50ec39a7", null ],
    [ "nwrite", "structpipe.html#a089f1ec4d2ea845105344cd1121dd3ae", null ],
    [ "readopen", "structpipe.html#a2c616f92018c3e3ed5337568ec96173f", null ],
    [ "writeopen", "structpipe.html#ae4254bf1d401e056beef1e2630c334e5", null ]
];