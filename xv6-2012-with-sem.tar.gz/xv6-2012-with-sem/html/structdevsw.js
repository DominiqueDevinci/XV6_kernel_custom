var structdevsw =
[
    [ "read", "structdevsw.html#af7a7637a9cbfae4c6167be073a4ce27a", null ],
    [ "write", "structdevsw.html#a116cc993ece86c6fa11057b78786cfe2", null ]
];