var timer_8c =
[
    [ "IO_TIMER1", "timer_8c.html#a95b5a23b2d1437404a4a197c0917dd86", null ],
    [ "TIMER_16BIT", "timer_8c.html#a8625ef46b29b0eb120042695f9610c87", null ],
    [ "TIMER_DIV", "timer_8c.html#a542df7535b53d76e88bf65fb562b1c5a", null ],
    [ "TIMER_FREQ", "timer_8c.html#acf926951944b6cf370b7229ebd50dd8b", null ],
    [ "TIMER_MODE", "timer_8c.html#af2a9f923fe45bcba36e26b19886d9d81", null ],
    [ "TIMER_RATEGEN", "timer_8c.html#ad9659e4ad696f017ad5002e4d4e9d176", null ],
    [ "TIMER_SEL0", "timer_8c.html#a6a4822642d40c248435692324a818010", null ],
    [ "timerinit", "timer_8c.html#a49af4bce992b520d5032364d0a4eb8ee", null ]
];