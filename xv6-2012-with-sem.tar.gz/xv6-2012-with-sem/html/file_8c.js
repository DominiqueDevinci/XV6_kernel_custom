var file_8c =
[
    [ "filealloc", "file_8c.html#a69d3d2dd94efa1f1ff8d0143f4d9b786", null ],
    [ "fileclose", "file_8c.html#ae557c81ab89c24219146144bb6adaa2c", null ],
    [ "filedup", "file_8c.html#a014992e93368bee9318b5e1ff575cb91", null ],
    [ "fileinit", "file_8c.html#a66bb5a4b304ea0f851dd999fc8195fa4", null ],
    [ "fileread", "file_8c.html#a1dc8c87c7e48bdaaf98e9c7047928f29", null ],
    [ "filestat", "file_8c.html#afff8e849fa54dea2a5a27dbb97474607", null ],
    [ "filewrite", "file_8c.html#ab8de757a0a9f58dcc6511ea5e46ebb88", null ],
    [ "devsw", "file_8c.html#aadbb32b41c0d0e9c19d6d8fa3a0a6502", null ],
    [ "file", "file_8c.html#a7cfa5243b3d349a415c7500c962fe9a5", null ],
    [ "ftable", "file_8c.html#a5e3713b2e8d8fca04c15e52b9a315620", null ],
    [ "lock", "file_8c.html#ab28e82cd5dda7d960095706a3ea20572", null ]
];