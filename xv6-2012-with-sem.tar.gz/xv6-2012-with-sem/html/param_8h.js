var param_8h =
[
    [ "KSTACKSIZE", "param_8h.html#a7735dc19a8cdc3fcafd4241184be4b41", null ],
    [ "LOGSIZE", "param_8h.html#acc7694167c7840a913939a1b90808b4c", null ],
    [ "MAXARG", "param_8h.html#a4c171d1ccc50f0b6ce7ad2f475eeba32", null ],
    [ "NBUF", "param_8h.html#ad51e2f8dffd163c263ec676a268d0f0a", null ],
    [ "NCPU", "param_8h.html#a2c4561c4c17cde39101c4e7a40d4492a", null ],
    [ "NDEV", "param_8h.html#aa564a41c8409694da49b0badf2bb2853", null ],
    [ "NFILE", "param_8h.html#a8485f4e81de2537e6a0935626167a775", null ],
    [ "NINODE", "param_8h.html#adabafa10c7951be7c875cd2ee212be85", null ],
    [ "NOFILE", "param_8h.html#a80bacbaea8dd6aecf216d85d981bcb21", null ],
    [ "NPROC", "param_8h.html#a810c5b751df5bb30588613ed91095129", null ],
    [ "ROOTDEV", "param_8h.html#ae9ce6b24fe2aae59ff60b469c35febbc", null ]
];