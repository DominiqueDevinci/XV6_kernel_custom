var ide_8c =
[
    [ "IDE_BSY", "ide_8c.html#aebe5f7f39eb6d658f4a430936dc1dfc2", null ],
    [ "IDE_CMD_READ", "ide_8c.html#ae117ee5b71546241f52d9088c0fffadc", null ],
    [ "IDE_CMD_WRITE", "ide_8c.html#ae7cbfd899670e7987022c3bb639e568d", null ],
    [ "IDE_DF", "ide_8c.html#a8856c5f8e07087f4cc462dc093539f75", null ],
    [ "IDE_DRDY", "ide_8c.html#a46b51ed8423e20960b46bd4451aad66b", null ],
    [ "IDE_ERR", "ide_8c.html#ae27406a5efbf146eebd69751e36b1d14", null ],
    [ "ideinit", "ide_8c.html#aefb190a6104cb58c0bc1f8fec88d1307", null ],
    [ "ideintr", "ide_8c.html#a709693afdb9b89d848e684e7acde1f8f", null ],
    [ "iderw", "ide_8c.html#a7f36b008f02088c86f76e98e05b55af5", null ]
];