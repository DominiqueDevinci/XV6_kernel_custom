var syscall_8h =
[
    [ "SYS_chdir", "syscall_8h.html#a02542ea0a822502c309e22863d71b849", null ],
    [ "SYS_close", "syscall_8h.html#a8ac7ddcf0e4789f3e705f35b8da40af3", null ],
    [ "SYS_dup", "syscall_8h.html#a6e98a8f905993a259782ac57a85dbcfc", null ],
    [ "SYS_exec", "syscall_8h.html#a3672b4a5863177cfdf4989e1f3a634b5", null ],
    [ "SYS_exit", "syscall_8h.html#a9ffbbdd04d43fb4c0d05d4363d351772", null ],
    [ "SYS_fork", "syscall_8h.html#a5eba4bd9e19de29f726910510e067d58", null ],
    [ "SYS_fstat", "syscall_8h.html#a71105a873ad172a54a16aa2f2d85534a", null ],
    [ "SYS_getpid", "syscall_8h.html#a7e0844c7709356d697013151cf51c69e", null ],
    [ "SYS_kill", "syscall_8h.html#ae72be7145975bab983df852500f507f4", null ],
    [ "SYS_link", "syscall_8h.html#a83209641ae7dbc27802761fde434ae5b", null ],
    [ "SYS_mkdir", "syscall_8h.html#a0b150013ad6fdc06e94a89c44cc4e780", null ],
    [ "SYS_mknod", "syscall_8h.html#a8da465de7045beb2e558bd601e946c1e", null ],
    [ "SYS_open", "syscall_8h.html#a3ba1dfe32baa7a51d8d45fd412d08b91", null ],
    [ "SYS_pipe", "syscall_8h.html#a780e0cccccb5dc0b1a6145c878c5004d", null ],
    [ "SYS_read", "syscall_8h.html#a4481bc3f0d65944cd6a9ecd6c5b93a55", null ],
    [ "SYS_sbrk", "syscall_8h.html#acceb23729a731ccd9c3ebd6f887b7256", null ],
    [ "SYS_sleep", "syscall_8h.html#a77eac7fe66c659f7731cda964a7ce3dc", null ],
    [ "SYS_unlink", "syscall_8h.html#aa968942341544d4bb806d11c7763e227", null ],
    [ "SYS_uptime", "syscall_8h.html#aafb554720ef5628c963c542258b1f639", null ],
    [ "SYS_wait", "syscall_8h.html#ad8fac614fe5ff393700eba18c0a1e75a", null ],
    [ "SYS_write", "syscall_8h.html#aa7425a6f80dc9c0ec789079cb6547542", null ]
];