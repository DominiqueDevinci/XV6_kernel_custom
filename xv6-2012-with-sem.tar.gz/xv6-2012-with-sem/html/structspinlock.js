var structspinlock =
[
    [ "cpu", "structspinlock.html#a01255252d6a6f1a4d5550f72dfe3a733", null ],
    [ "locked", "structspinlock.html#a2468e5b98a0b805a0a174eda5d09c6ad", null ],
    [ "name", "structspinlock.html#a5ac083a645d964373f022d03df4849c8", null ],
    [ "pcs", "structspinlock.html#a96a0f9277e455aac1e0f848607cb1a2d", null ]
];