var buf_8h =
[
    [ "buf", "structbuf.html", "structbuf" ],
    [ "B_BUSY", "buf_8h.html#abd2b4f84a360399fba6535a0d5f33298", null ],
    [ "B_DIRTY", "buf_8h.html#adc32011df267adb9740bcd0abf0f0663", null ],
    [ "B_VALID", "buf_8h.html#afab4199c0d27da71061f1c0cd5b51520", null ]
];