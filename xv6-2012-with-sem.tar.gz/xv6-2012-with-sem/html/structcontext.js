var structcontext =
[
    [ "ebp", "structcontext.html#a8d9d61f0e845561448cf50ddf637e6b3", null ],
    [ "ebx", "structcontext.html#a685d686dce7abed5d536f3304c4692b9", null ],
    [ "edi", "structcontext.html#a5d017b35dd2b40671e27c7ae6c276b23", null ],
    [ "eip", "structcontext.html#ae590d07d633d3642402cd0b25e053568", null ],
    [ "esi", "structcontext.html#ab40e0917bb6e7e462049fc4151201f0a", null ]
];