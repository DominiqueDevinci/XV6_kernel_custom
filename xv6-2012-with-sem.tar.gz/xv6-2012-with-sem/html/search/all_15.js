var searchData=
[
  ['v2p',['V2P',['../memlayout_8h.html#a5021188bc7da1304f27e913aee183407',1,'memlayout.h']]],
  ['v2p_5fwo',['V2P_WO',['../memlayout_8h.html#a07c445cd5425fc1d69188d1e6d511e4b',1,'memlayout.h']]],
  ['vaddr',['vaddr',['../structproghdr.html#aa974042c9a1f07947e76c236ba11fd96',1,'proghdr']]],
  ['validateint',['validateint',['../usertests_8c.html#a426d02dfb5155266933466f604bed0b2',1,'usertests.c']]],
  ['validatetest',['validatetest',['../usertests_8c.html#a98d8496ecb698b9400831f2718d805c3',1,'usertests.c']]],
  ['vectors',['vectors',['../trap_8c.html#a3e6e0e8b5ba8014e09de2d9aa3740486',1,'trap.c']]],
  ['ver',['VER',['../lapic_8c.html#a98ed931f97fef7e06e3ea441d0326c67',1,'lapic.c']]],
  ['version',['version',['../structelfhdr.html#acb7e2a1d2504d82c52a9fa9b00bea040',1,'elfhdr::version()'],['../structmpconf.html#aa6ea6b1d12a723848cc34b199ddd8aef',1,'mpconf::version()'],['../structmpproc.html#aa6ea6b1d12a723848cc34b199ddd8aef',1,'mpproc::version()'],['../structmpioapic.html#aa6ea6b1d12a723848cc34b199ddd8aef',1,'mpioapic::version()']]],
  ['vm_2ec',['vm.c',['../vm_8c.html',1,'']]],
  ['vmenable',['vmenable',['../defs_8h.html#a29a329af50004b3156504840ac815c7c',1,'defs.h']]]
];
