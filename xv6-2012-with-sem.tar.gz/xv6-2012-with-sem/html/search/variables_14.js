var searchData=
[
  ['uninit',['uninit',['../usertests_8c.html#a7def0d79bfddb934aaf3fe627c97daf3',1,'usertests.c']]],
  ['use_5flock',['use_lock',['../kalloc_8c.html#a37d4eb2590728645fea0e2da2b94e210',1,'kalloc.c']]],
  ['usedblocks',['usedblocks',['../mkfs_8c.html#ac88cd5b9c7c3cdd1747427b705b3f3df',1,'mkfs.c']]]
];
