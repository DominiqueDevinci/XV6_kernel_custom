var searchData=
[
  ['zeroes',['zeroes',['../mkfs_8c.html#acfc6531cf5986cddcab420a16cc7f7ff',1,'mkfs.c']]],
  ['zombie',['ZOMBIE',['../proc_8h.html#aa1ced7d2b60040fded3fa873d0c03ba7a5dfb36109b24f39d54d5c3f48f53def8',1,'proc.h']]],
  ['zombie_2ec',['zombie.c',['../zombie_8c.html',1,'']]]
];
