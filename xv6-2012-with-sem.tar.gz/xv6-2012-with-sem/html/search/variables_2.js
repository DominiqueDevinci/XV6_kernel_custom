var searchData=
[
  ['base_5f15_5f0',['base_15_0',['../structsegdesc.html#a5b20f16107a37790349fb5c3856c6c01',1,'segdesc']]],
  ['base_5f23_5f16',['base_23_16',['../structsegdesc.html#a80d2085d2e280c3bbd1420fb452680e2',1,'segdesc']]],
  ['base_5f31_5f24',['base_31_24',['../structsegdesc.html#aa4e2821f8c7d1fb00ed552f59d07f59a',1,'segdesc']]],
  ['bcache',['bcache',['../bio_8c.html#a8c840c340a1233a78bdb2af607bbbcfc',1,'bio.c']]],
  ['bitblocks',['bitblocks',['../mkfs_8c.html#a64107ad2f4fc60e3781593ebbea94582',1,'mkfs.c']]],
  ['buf',['buf',['../bio_8c.html#a72ee90c61d41547b10a533c219e081c6',1,'buf():&#160;bio.c'],['../cat_8c.html#a78a05cf530dddc61e7a26aefe187bd31',1,'buf():&#160;cat.c'],['../console_8c.html#aa427837782b05b05204809dfba33c8f5',1,'buf():&#160;console.c'],['../grep_8c.html#ac75fce8692fd1d41a8985f6aacc4a175',1,'buf():&#160;grep.c'],['../usertests_8c.html#ad42dafc8306f25c145c246f973b420cf',1,'buf():&#160;usertests.c'],['../wc_8c.html#a78a05cf530dddc61e7a26aefe187bd31',1,'buf():&#160;wc.c']]],
  ['busy',['busy',['../structlog.html#acd5bede9e6d8c62423cdd428355933bd',1,'log']]]
];
