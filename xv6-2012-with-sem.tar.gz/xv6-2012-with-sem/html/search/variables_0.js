var searchData=
[
  ['_5fbinary_5ffs_5fimg_5fsize',['_binary_fs_img_size',['../memide_8c.html#a10b9652e23b65245bbc2126350c915d3',1,'memide.c']]],
  ['_5fbinary_5ffs_5fimg_5fstart',['_binary_fs_img_start',['../memide_8c.html#af73b74f3a51ba441c3b68b1cf3e276c3',1,'memide.c']]]
];
