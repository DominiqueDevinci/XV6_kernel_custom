var searchData=
[
  ['qnext',['qnext',['../structbuf.html#a479532a4750e78d1ad819ef4121f6def',1,'buf']]]
];
