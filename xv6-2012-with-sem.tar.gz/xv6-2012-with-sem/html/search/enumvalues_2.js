var searchData=
[
  ['runnable',['RUNNABLE',['../proc_8h.html#aa1ced7d2b60040fded3fa873d0c03ba7a269b90433e40460a2c0044a0b3e15694',1,'proc.h']]],
  ['running',['RUNNING',['../proc_8h.html#aa1ced7d2b60040fded3fa873d0c03ba7a1061be6c3fb88d32829cba6f6b2be304',1,'proc.h']]]
];
