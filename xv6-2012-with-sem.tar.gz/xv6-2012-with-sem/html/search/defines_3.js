var searchData=
[
  ['deassert',['DEASSERT',['../lapic_8c.html#a8b48e10f84b81902cf66c89ac52649b7',1,'lapic.c']]],
  ['delivs',['DELIVS',['../lapic_8c.html#a5f0b856b460d14d6fac161e35cfdb9d1',1,'lapic.c']]],
  ['devspace',['DEVSPACE',['../memlayout_8h.html#a643ab4c8a98a6f7bfde12c8f52f6aafa',1,'memlayout.h']]],
  ['dirsiz',['DIRSIZ',['../fs_8h.html#a48246fb9e5cb7f6a71ebc9ebc2f06562',1,'fs.h']]],
  ['dpl_5fuser',['DPL_USER',['../mmu_8h.html#a060d4d4e32af81cab881fe77e58d7b78',1,'mmu.h']]]
];
