var searchData=
[
  ['fd_5finode',['FD_INODE',['../structfile.html#adc29c2ff13d900c2f185ee95427fb06ca45efb38f6972a89c2237550ef6cd542c',1,'file']]],
  ['fd_5fnone',['FD_NONE',['../structfile.html#adc29c2ff13d900c2f185ee95427fb06ca949fd72b27639c27329b150ec9de33cd',1,'file']]],
  ['fd_5fpipe',['FD_PIPE',['../structfile.html#adc29c2ff13d900c2f185ee95427fb06caab625bb8391962abb9337db42d7909d6',1,'file']]]
];
