var searchData=
[
  ['chan',['chan',['../structproc.html#ae26528bc7e93e1eb8573a30309dc1424',1,'proc']]],
  ['checksum',['checksum',['../structmp.html#a282c64bb49f098de8b45dfc535c91ac5',1,'mp::checksum()'],['../structmpconf.html#a282c64bb49f098de8b45dfc535c91ac5',1,'mpconf::checksum()']]],
  ['cmd',['cmd',['../structredircmd.html#ae827072868c061a3985f9032a4522673',1,'redircmd::cmd()'],['../structbackcmd.html#ae827072868c061a3985f9032a4522673',1,'backcmd::cmd()']]],
  ['context',['context',['../structproc.html#a30183e0aad45d3a56e1a22d3a8fecb17',1,'proc']]],
  ['cpu',['cpu',['../structcpu.html#a01255252d6a6f1a4d5550f72dfe3a733',1,'cpu::cpu()'],['../structspinlock.html#a01255252d6a6f1a4d5550f72dfe3a733',1,'spinlock::cpu()']]],
  ['cpus',['cpus',['../mp_8c.html#a6d2633e73724907b582dfe6938ed7bb9',1,'cpus():&#160;mp.c'],['../proc_8h.html#a6d2633e73724907b582dfe6938ed7bb9',1,'cpus():&#160;mp.c']]],
  ['cr3',['cr3',['../structtaskstate.html#a915afcdc183379971c3d7f5d665017c6',1,'taskstate']]],
  ['cs',['cs',['../structtaskstate.html#a2c1a506f83f7be334e4128748f4a2eaa',1,'taskstate::cs()'],['../structgatedesc.html#a21ff1dca4ee9146feae362cb81bdb73b',1,'gatedesc::cs()'],['../structtrapframe.html#a2c1a506f83f7be334e4128748f4a2eaa',1,'trapframe::cs()']]],
  ['cwd',['cwd',['../structproc.html#a9dfc3cbb1d3bc4f1b196c07092aa64ec',1,'proc']]]
];
