var searchData=
[
  ['data',['data',['../structbuf.html#aa6cf955e5b0bdedd2b7d1461838a1134',1,'buf::data()'],['../structioapic.html#a4257a9563e3f5c94350c002195cecc47',1,'ioapic::data()'],['../structpipe.html#a4b9a650598bf6f6eff13ff36793ec4f4',1,'pipe::data()'],['../vm_8c.html#a923b2158227405b9f7a6eceb6c7104c8',1,'data():&#160;vm.c']]],
  ['db',['db',['../structsegdesc.html#a04ab5582b63d915355818185ba20a9c4',1,'segdesc']]],
  ['deallocuvm',['deallocuvm',['../defs_8h.html#ac45969a8875b6dc87245e0a642aa2d8d',1,'deallocuvm(pde_t *, uint, uint):&#160;vm.c'],['../vm_8c.html#a6d3019ea15a9bfdc5131ae97f3623c49',1,'deallocuvm(pde_t *pgdir, uint oldsz, uint newsz):&#160;vm.c']]],
  ['deassert',['DEASSERT',['../lapic_8c.html#a8b48e10f84b81902cf66c89ac52649b7',1,'lapic.c']]],
  ['defs_2eh',['defs.h',['../defs_8h.html',1,'']]],
  ['delivs',['DELIVS',['../lapic_8c.html#a5f0b856b460d14d6fac161e35cfdb9d1',1,'lapic.c']]],
  ['dev',['dev',['../structbuf.html#aaf61a1db4c34c23857104abc633d8ee6',1,'buf::dev()'],['../structinode.html#aaf61a1db4c34c23857104abc633d8ee6',1,'inode::dev()'],['../structlog.html#a22c99b5ae74d0e3dcf126f0d950538e4',1,'log::dev()'],['../structstat.html#a22c99b5ae74d0e3dcf126f0d950538e4',1,'stat::dev()']]],
  ['devspace',['DEVSPACE',['../memlayout_8h.html#a643ab4c8a98a6f7bfde12c8f52f6aafa',1,'memlayout.h']]],
  ['devsw',['devsw',['../structdevsw.html',1,'devsw'],['../file_8c.html#aadbb32b41c0d0e9c19d6d8fa3a0a6502',1,'devsw():&#160;file.c'],['../file_8h.html#aef498b4c2cbc1a4286c67ff5f20afec9',1,'devsw():&#160;file.c']]],
  ['dinode',['dinode',['../structdinode.html',1,'']]],
  ['dirent',['dirent',['../structdirent.html',1,'']]],
  ['dirfile',['dirfile',['../usertests_8c.html#aedd6d3f148dd5c99b47900215c1ac43f',1,'usertests.c']]],
  ['dirlink',['dirlink',['../defs_8h.html#ae4ccea0aa02557162963e597737f665a',1,'dirlink(struct inode *, char *, uint):&#160;fs.c'],['../fs_8c.html#a69a135a0e8a06d9f306d77ebc0c1f7a0',1,'dirlink(struct inode *dp, char *name, uint inum):&#160;fs.c']]],
  ['dirlookup',['dirlookup',['../defs_8h.html#a91ded9e61402d5e0d9f16b2a8cbff5c3',1,'dirlookup(struct inode *, char *, uint *):&#160;fs.c'],['../fs_8c.html#aa182c62fade7a0bae9408830d5e06d4f',1,'dirlookup(struct inode *dp, char *name, uint *poff):&#160;fs.c']]],
  ['dirsiz',['DIRSIZ',['../fs_8h.html#a48246fb9e5cb7f6a71ebc9ebc2f06562',1,'fs.h']]],
  ['dirtest',['dirtest',['../usertests_8c.html#a8db9f9a2634bab29096bab0b8bc6945c',1,'usertests.c']]],
  ['dpl',['dpl',['../structsegdesc.html#af007c16108fee6bd537fac7128283b6e',1,'segdesc::dpl()'],['../structgatedesc.html#af007c16108fee6bd537fac7128283b6e',1,'gatedesc::dpl()']]],
  ['dpl_5fuser',['DPL_USER',['../mmu_8h.html#a060d4d4e32af81cab881fe77e58d7b78',1,'mmu.h']]],
  ['ds',['ds',['../structtaskstate.html#a0d354e57548a3fa1b2f8ab075a9bcb7e',1,'taskstate::ds()'],['../structtrapframe.html#a0d354e57548a3fa1b2f8ab075a9bcb7e',1,'trapframe::ds()']]],
  ['dup',['dup',['../user_8h.html#a530ea95b243a1bf148adaf399e2a6292',1,'user.h']]]
];
