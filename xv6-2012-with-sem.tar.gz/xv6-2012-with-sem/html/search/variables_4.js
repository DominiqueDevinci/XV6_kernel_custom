var searchData=
[
  ['data',['data',['../structbuf.html#aa6cf955e5b0bdedd2b7d1461838a1134',1,'buf::data()'],['../structioapic.html#a4257a9563e3f5c94350c002195cecc47',1,'ioapic::data()'],['../structpipe.html#a4b9a650598bf6f6eff13ff36793ec4f4',1,'pipe::data()'],['../vm_8c.html#a923b2158227405b9f7a6eceb6c7104c8',1,'data():&#160;vm.c']]],
  ['db',['db',['../structsegdesc.html#a04ab5582b63d915355818185ba20a9c4',1,'segdesc']]],
  ['dev',['dev',['../structbuf.html#aaf61a1db4c34c23857104abc633d8ee6',1,'buf::dev()'],['../structinode.html#aaf61a1db4c34c23857104abc633d8ee6',1,'inode::dev()'],['../structlog.html#a22c99b5ae74d0e3dcf126f0d950538e4',1,'log::dev()'],['../structstat.html#a22c99b5ae74d0e3dcf126f0d950538e4',1,'stat::dev()']]],
  ['devsw',['devsw',['../file_8c.html#aadbb32b41c0d0e9c19d6d8fa3a0a6502',1,'devsw():&#160;file.c'],['../file_8h.html#aef498b4c2cbc1a4286c67ff5f20afec9',1,'devsw():&#160;file.c']]],
  ['dpl',['dpl',['../structsegdesc.html#af007c16108fee6bd537fac7128283b6e',1,'segdesc::dpl()'],['../structgatedesc.html#af007c16108fee6bd537fac7128283b6e',1,'gatedesc::dpl()']]],
  ['ds',['ds',['../structtaskstate.html#a0d354e57548a3fa1b2f8ab075a9bcb7e',1,'taskstate::ds()'],['../structtrapframe.html#a0d354e57548a3fa1b2f8ab075a9bcb7e',1,'trapframe::ds()']]]
];
