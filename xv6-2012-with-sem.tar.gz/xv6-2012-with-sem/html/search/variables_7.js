var searchData=
[
  ['g',['g',['../structsegdesc.html#a507f46d64a589eaa3bf729789889283c',1,'segdesc']]],
  ['gdt',['gdt',['../structcpu.html#ad9d6d1fdf72705e51d5024df0f2e69a5',1,'cpu::gdt()'],['../vm_8c.html#ad9d6d1fdf72705e51d5024df0f2e69a5',1,'gdt():&#160;vm.c']]],
  ['gs',['gs',['../structtaskstate.html#aaeba1ea8da31d7740b55bc9d8efcacc5',1,'taskstate::gs()'],['../structtrapframe.html#aaeba1ea8da31d7740b55bc9d8efcacc5',1,'trapframe::gs()']]]
];
