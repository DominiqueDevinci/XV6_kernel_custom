var indexSectionsWithContent =
{
  0: "_abcdefghiklmnopqrstuvwxyz",
  1: "bcdefghilmprst",
  2: "abcdefgiklmprstuvwxz",
  3: "_abcdefghiklmnoprstuvwxy",
  4: "_abcdefghiklmnopqrstuvwxz",
  5: "ahpu",
  6: "p",
  7: "efrsuz",
  8: "abcdefiklmnoprstvx"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros"
};

