var searchData=
[
  ['acquire',['acquire',['../defs_8h.html#afe4ef8638f1ecb962a6e67fb086ee3b8',1,'acquire(struct spinlock *):&#160;spinlock.c'],['../spinlock_8c.html#aed377f16a085b00de3a4b32392adbdfb',1,'acquire(struct spinlock *lk):&#160;spinlock.c']]],
  ['allocuvm',['allocuvm',['../defs_8h.html#a67f50b6f85756f02b5acdcb084d51b9f',1,'allocuvm(pde_t *, uint, uint):&#160;vm.c'],['../vm_8c.html#afea0f0a82a9f9c7aae26f90b5e0836c6',1,'allocuvm(pde_t *pgdir, uint oldsz, uint newsz):&#160;vm.c']]],
  ['argint',['argint',['../defs_8h.html#a75bc8d8c7ea0b4b39d4f470e18e0dba7',1,'argint(int, int *):&#160;syscall.c'],['../syscall_8c.html#ade56ef2176f85cd61e7b91b400e7d4d3',1,'argint(int n, int *ip):&#160;syscall.c']]],
  ['argptr',['argptr',['../defs_8h.html#a05c7464938c27eb91540c06ec6137f26',1,'argptr(int, char **, int):&#160;syscall.c'],['../syscall_8c.html#a6ade9205d1f46b759cf93b60513a3421',1,'argptr(int n, char **pp, int size):&#160;syscall.c']]],
  ['argstr',['argstr',['../defs_8h.html#afc00cb2e6a06b1021f3d82fa4d0eff07',1,'argstr(int, char **):&#160;syscall.c'],['../syscall_8c.html#a662eedd65f3e2165093842b80e3bc024',1,'argstr(int n, char **pp):&#160;syscall.c']]],
  ['asm',['asm',['../proc_8h.html#a878a634b88f305d27996e9c976dd76c3',1,'asm(&quot;%gs:0&quot;):&#160;proc.h'],['../proc_8h.html#a6424715dee020940c16737056af70edf',1,'asm(&quot;%gs:4&quot;):&#160;proc.h']]],
  ['atoi',['atoi',['../ulib_8c.html#a30670a60464f77af17dfb353353d6df8',1,'atoi(const char *s):&#160;ulib.c'],['../user_8h.html#a4e157d18591ba54c92e4da99a3d1ccae',1,'atoi(const char *):&#160;ulib.c']]]
];
