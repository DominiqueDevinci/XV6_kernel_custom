var searchData=
[
  ['deallocuvm',['deallocuvm',['../defs_8h.html#ac45969a8875b6dc87245e0a642aa2d8d',1,'deallocuvm(pde_t *, uint, uint):&#160;vm.c'],['../vm_8c.html#a6d3019ea15a9bfdc5131ae97f3623c49',1,'deallocuvm(pde_t *pgdir, uint oldsz, uint newsz):&#160;vm.c']]],
  ['dirfile',['dirfile',['../usertests_8c.html#aedd6d3f148dd5c99b47900215c1ac43f',1,'usertests.c']]],
  ['dirlink',['dirlink',['../defs_8h.html#ae4ccea0aa02557162963e597737f665a',1,'dirlink(struct inode *, char *, uint):&#160;fs.c'],['../fs_8c.html#a69a135a0e8a06d9f306d77ebc0c1f7a0',1,'dirlink(struct inode *dp, char *name, uint inum):&#160;fs.c']]],
  ['dirlookup',['dirlookup',['../defs_8h.html#a91ded9e61402d5e0d9f16b2a8cbff5c3',1,'dirlookup(struct inode *, char *, uint *):&#160;fs.c'],['../fs_8c.html#aa182c62fade7a0bae9408830d5e06d4f',1,'dirlookup(struct inode *dp, char *name, uint *poff):&#160;fs.c']]],
  ['dirtest',['dirtest',['../usertests_8c.html#a8db9f9a2634bab29096bab0b8bc6945c',1,'usertests.c']]],
  ['dup',['dup',['../user_8h.html#a530ea95b243a1bf148adaf399e2a6292',1,'user.h']]]
];
