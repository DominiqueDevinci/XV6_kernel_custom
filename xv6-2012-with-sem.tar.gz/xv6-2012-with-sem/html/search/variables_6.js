var searchData=
[
  ['fd',['fd',['../structredircmd.html#a6f8059414f0228f0256115e024eeed4b',1,'redircmd']]],
  ['feature',['feature',['../structmpproc.html#a2336e944364e02cfce4790bb4f0939fb',1,'mpproc']]],
  ['file',['file',['../structredircmd.html#adf16cd437526a5c5e0e0af87745acbb8',1,'redircmd::file()'],['../file_8c.html#a7cfa5243b3d349a415c7500c962fe9a5',1,'file():&#160;file.c']]],
  ['filesz',['filesz',['../structproghdr.html#af68648ec9784a595235d016a78d4e443',1,'proghdr']]],
  ['flags',['flags',['../structbuf.html#ac8bf36fe0577cba66bccda3a6f7e80a4',1,'buf::flags()'],['../structelfhdr.html#a660f9db871d26052904976a8bfe8432d',1,'elfhdr::flags()'],['../structproghdr.html#a660f9db871d26052904976a8bfe8432d',1,'proghdr::flags()'],['../structinode.html#ac8bf36fe0577cba66bccda3a6f7e80a4',1,'inode::flags()'],['../structmpproc.html#abe146a6a9523880d7ce48965f8d07b34',1,'mpproc::flags()'],['../structmpioapic.html#abe146a6a9523880d7ce48965f8d07b34',1,'mpioapic::flags()']]],
  ['freeblock',['freeblock',['../mkfs_8c.html#a8d3a0b59d5f6e59c8b7c0bbdab41ab15',1,'mkfs.c']]],
  ['freeinode',['freeinode',['../mkfs_8c.html#acee9059b25c8d81ef2b9cfedded17d48',1,'mkfs.c']]],
  ['freelist',['freelist',['../kalloc_8c.html#a25f1f0e27ad1cafebbde0b8b7455afb4',1,'kalloc.c']]],
  ['fs',['fs',['../structtaskstate.html#a5f3d679db589770026f3d927f3fed7b7',1,'taskstate::fs()'],['../structtrapframe.html#a5f3d679db589770026f3d927f3fed7b7',1,'trapframe::fs()']]],
  ['fsfd',['fsfd',['../mkfs_8c.html#a44f12de41bc5a5ada9e5fff19c18201c',1,'mkfs.c']]],
  ['ftable',['ftable',['../file_8c.html#a5e3713b2e8d8fca04c15e52b9a315620',1,'file.c']]]
];
