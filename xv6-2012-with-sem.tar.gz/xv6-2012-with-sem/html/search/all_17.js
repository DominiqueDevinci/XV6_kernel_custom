var searchData=
[
  ['x',['x',['../unionheader.html#a5f369a9edd645986a45d0c159773c740',1,'header']]],
  ['x1',['X1',['../lapic_8c.html#a1964818ccd90a6173ea48cecb652feeb',1,'lapic.c']]],
  ['x86_2eh',['x86.h',['../x86_8h.html',1,'']]],
  ['xchecksum',['xchecksum',['../structmpconf.html#a6f8d578004c11e0bdbf514588ccb1697',1,'mpconf']]],
  ['xint',['xint',['../mkfs_8c.html#a0cb088f1b4dabee9a6056b88a8f813ef',1,'mkfs.c']]],
  ['xlength',['xlength',['../structmpconf.html#a74abe1c31d3783b9bb39334ffad032b6',1,'mpconf']]],
  ['xshort',['xshort',['../mkfs_8c.html#ac6dbbb3aaeee7114cf795be284be08ce',1,'mkfs.c']]]
];
