var searchData=
[
  ['backcmd',['backcmd',['../sh_8c.html#a8f1212e0b392bac41dcc6ff160b5dcdb',1,'sh.c']]],
  ['balloc',['balloc',['../mkfs_8c.html#a327cdfc7a74165d8922ec6c8ba256906',1,'mkfs.c']]],
  ['begin_5ftrans',['begin_trans',['../defs_8h.html#a65aa129dd26f9d67e0dd0675dba740ef',1,'begin_trans():&#160;log.c'],['../log_8c.html#a87de7506dacca31ef3fee3e888a7ab9c',1,'begin_trans(void):&#160;log.c']]],
  ['bigargtest',['bigargtest',['../usertests_8c.html#ac5b5d4517586be6396b4f3b37445945a',1,'usertests.c']]],
  ['bigdir',['bigdir',['../usertests_8c.html#aa0d46fcb43667c805b84ea7e1ff6100a',1,'usertests.c']]],
  ['bigfile',['bigfile',['../usertests_8c.html#a86fe524d99d69c18a335512cf3405b31',1,'usertests.c']]],
  ['bigwrite',['bigwrite',['../usertests_8c.html#a57e55b2d0161d62bb99765ca3de43e35',1,'usertests.c']]],
  ['binit',['binit',['../bio_8c.html#a53cca0ddc98c5f1de37124eca2575a59',1,'binit(void):&#160;bio.c'],['../defs_8h.html#a53cca0ddc98c5f1de37124eca2575a59',1,'binit(void):&#160;bio.c']]],
  ['bootmain',['bootmain',['../bootmain_8c.html#a0d198d492591e1b70a8a12109408a7e4',1,'bootmain.c']]],
  ['bread',['bread',['../bio_8c.html#ac09898fdd6868e88ff35f498fa6ef52f',1,'bread(uint dev, uint sector):&#160;bio.c'],['../defs_8h.html#a90c72cf2140fdf1612484117327220af',1,'bread(uint, uint):&#160;bio.c']]],
  ['brelse',['brelse',['../bio_8c.html#ab5335aeb503731104314321a78a6d727',1,'brelse(struct buf *b):&#160;bio.c'],['../defs_8h.html#aa31ec2f79e0456737a9680270bc1841b',1,'brelse(struct buf *):&#160;bio.c']]],
  ['bsstest',['bsstest',['../usertests_8c.html#a0b0ff95e564df3c3e8fc977226b75de7',1,'usertests.c']]],
  ['bwrite',['bwrite',['../bio_8c.html#a63c899c13b176ddf80064d32225e1298',1,'bwrite(struct buf *b):&#160;bio.c'],['../defs_8h.html#a1bfd775f14ad3dfee354ee3897ecd28d',1,'bwrite(struct buf *):&#160;bio.c']]]
];
