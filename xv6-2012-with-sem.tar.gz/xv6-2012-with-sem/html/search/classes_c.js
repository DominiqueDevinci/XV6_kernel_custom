var searchData=
[
  ['segdesc',['segdesc',['../structsegdesc.html',1,'']]],
  ['spinlock',['spinlock',['../structspinlock.html',1,'']]],
  ['stat',['stat',['../structstat.html',1,'']]],
  ['superblock',['superblock',['../structsuperblock.html',1,'']]]
];
