var searchData=
[
  ['n',['n',['../structlogheader.html#a76f11d9a0a47b94f72c2d0e77fb32240',1,'logheader']]],
  ['name',['name',['../structdirent.html#a8ccdb14ce534c8ad0b98a76b02dcdb76',1,'dirent::name()'],['../structproc.html#acd328517a6cf718155c2e6e22b671ca9',1,'proc::name()'],['../structspinlock.html#a5ac083a645d964373f022d03df4849c8',1,'spinlock::name()'],['../usertests_8c.html#aee754febd402311e2a552cb0d6ab6629',1,'name():&#160;usertests.c']]],
  ['nblocks',['nblocks',['../structsuperblock.html#acca6315b99c9786037236e521f8b2556',1,'superblock::nblocks()'],['../mkfs_8c.html#a076c8e8b7f7acccc46cd356bd8776b26',1,'nblocks():&#160;mkfs.c']]],
  ['ncli',['ncli',['../structcpu.html#a47f2115921397412b52d8aa2680510ec',1,'cpu']]],
  ['ncpu',['ncpu',['../mp_8c.html#a6201a0661c3d5b88df5f63529298eb48',1,'ncpu():&#160;mp.c'],['../proc_8h.html#a6201a0661c3d5b88df5f63529298eb48',1,'ncpu():&#160;mp.c']]],
  ['next',['next',['../structbuf.html#a5a609449f1b0b08ae96fe8b29e866fd7',1,'buf::next()'],['../structrun.html#afa37bad156291ffb38122b28ebd546ef',1,'run::next()']]],
  ['nextpid',['nextpid',['../proc_8c.html#aec016216766697de7529c7b9cb5beda9',1,'proc.c']]],
  ['ninodes',['ninodes',['../structsuperblock.html#a9df4c697e9b13fc3226bb66e46b3b409',1,'superblock::ninodes()'],['../mkfs_8c.html#a2df6f8ae5d8798691d40217c434098e5',1,'ninodes():&#160;mkfs.c']]],
  ['nlink',['nlink',['../structinode.html#aa7e1ed70907ed9a2fc9c9a7c24cd0d4d',1,'inode::nlink()'],['../structdinode.html#aa7e1ed70907ed9a2fc9c9a7c24cd0d4d',1,'dinode::nlink()'],['../structstat.html#aa7e1ed70907ed9a2fc9c9a7c24cd0d4d',1,'stat::nlink()']]],
  ['nlog',['nlog',['../structsuperblock.html#ace18225da7fd09db4020dfe4f9eade8a',1,'superblock::nlog()'],['../mkfs_8c.html#aa86ff3fab07bd3139fcd159de0ffce90',1,'nlog():&#160;mkfs.c']]],
  ['nread',['nread',['../structpipe.html#a0e346df9e608d0a7d2c8538f50ec39a7',1,'pipe']]],
  ['nwrite',['nwrite',['../structpipe.html#a089f1ec4d2ea845105344cd1121dd3ae',1,'pipe']]]
];
