var searchData=
[
  ['o_5fcreate',['O_CREATE',['../fcntl_8h.html#ab40a23079c3b9a7e25ffdc8108c7fb02',1,'fcntl.h']]],
  ['o_5frdonly',['O_RDONLY',['../fcntl_8h.html#a7a68c9ffaac7dbcd652225dd7c06a54b',1,'fcntl.h']]],
  ['o_5frdwr',['O_RDWR',['../fcntl_8h.html#abb0586253488ee61072b73557eeb873b',1,'fcntl.h']]],
  ['o_5fwronly',['O_WRONLY',['../fcntl_8h.html#a11b644a8526139c4cc1850dac1271ced',1,'fcntl.h']]],
  ['oemlength',['oemlength',['../structmpconf.html#a1ceb9c0f37d610f220e21ff80705be9c',1,'mpconf']]],
  ['oemtable',['oemtable',['../structmpconf.html#a4a32c8dcc1dc530dd624029c57e7cc5c',1,'mpconf']]],
  ['oesp',['oesp',['../structtrapframe.html#a2fe573b67842f4aaa53302d128ac3ef3',1,'trapframe']]],
  ['off',['off',['../structproghdr.html#a1aeb2e4b0cfd549f8fb46fb7e08f7e3e',1,'proghdr::off()'],['../structfile.html#a1aeb2e4b0cfd549f8fb46fb7e08f7e3e',1,'file::off()']]],
  ['off_5f15_5f0',['off_15_0',['../structgatedesc.html#a0bf2673f8a3b3345556cc583c08bfcbf',1,'gatedesc']]],
  ['off_5f31_5f16',['off_31_16',['../structgatedesc.html#acda895cddc31853ba2be2ca38f9fc106',1,'gatedesc']]],
  ['ofile',['ofile',['../structproc.html#a86c51eb2e4daa425944e034bfad64fb8',1,'proc']]],
  ['open',['open',['../user_8h.html#a2955ebac5bec99d94ed565e5404240da',1,'user.h']]],
  ['opentest',['opentest',['../usertests_8c.html#ae7c61791dd2cfb8ad59b4c6e87685c07',1,'usertests.c']]]
];
