var searchData=
[
  ['uart_2ec',['uart.c',['../uart_8c.html',1,'']]],
  ['uartinit',['uartinit',['../defs_8h.html#a79fa7b73d0d61fdd15d30768a395437d',1,'uartinit(void):&#160;uart.c'],['../uart_8c.html#a79fa7b73d0d61fdd15d30768a395437d',1,'uartinit(void):&#160;uart.c']]],
  ['uartintr',['uartintr',['../defs_8h.html#aa64047002b0e84e2611ebf7dc46b7c99',1,'uartintr(void):&#160;uart.c'],['../uart_8c.html#aa64047002b0e84e2611ebf7dc46b7c99',1,'uartintr(void):&#160;uart.c']]],
  ['uartputc',['uartputc',['../defs_8h.html#a571626618a1f05ff6854802e936845d6',1,'uartputc(int):&#160;uart.c'],['../uart_8c.html#a55840fa098ac21df6535d6ac91956d07',1,'uartputc(int c):&#160;uart.c']]],
  ['uchar',['uchar',['../types_8h.html#a65f85814a8290f9797005d3b28e7e5fc',1,'types.h']]],
  ['uint',['uint',['../types_8h.html#a91ad9478d81a7aaf2593e8d9c3d06a14',1,'types.h']]],
  ['ulib_2ec',['ulib.c',['../ulib_8c.html',1,'']]],
  ['umalloc_2ec',['umalloc.c',['../umalloc_8c.html',1,'']]],
  ['uninit',['uninit',['../usertests_8c.html#a7def0d79bfddb934aaf3fe627c97daf3',1,'usertests.c']]],
  ['unlink',['unlink',['../user_8h.html#a65a95f51eb9a357f7bef0ebc501b1983',1,'user.h']]],
  ['unlinkread',['unlinkread',['../usertests_8c.html#a3331ced6fb67502a2e5277260d4f5aec',1,'usertests.c']]],
  ['unused',['UNUSED',['../proc_8h.html#aa1ced7d2b60040fded3fa873d0c03ba7aa09b651ef326a9d8efcee5cc5b720ab4',1,'proc.h']]],
  ['uptime',['uptime',['../user_8h.html#ab637d1dd2fecad1cb0c91a42597a8dbc',1,'user.h']]],
  ['use_5flock',['use_lock',['../kalloc_8c.html#a37d4eb2590728645fea0e2da2b94e210',1,'kalloc.c']]],
  ['usedblocks',['usedblocks',['../mkfs_8c.html#ac88cd5b9c7c3cdd1747427b705b3f3df',1,'mkfs.c']]],
  ['user_2eh',['user.h',['../user_8h.html',1,'']]],
  ['userinit',['userinit',['../defs_8h.html#a81c8a6a0cae413bc81aa223f7f7b7205',1,'userinit(void):&#160;proc.c'],['../proc_8c.html#a81c8a6a0cae413bc81aa223f7f7b7205',1,'userinit(void):&#160;proc.c']]],
  ['usertests_2ec',['usertests.c',['../usertests_8c.html',1,'']]],
  ['ushort',['ushort',['../types_8h.html#ab95f123a6c9bcfee6a343170ef8c5f69',1,'types.h']]],
  ['uva2ka',['uva2ka',['../defs_8h.html#adcf8d57f1ee45c47df3f63a950f53143',1,'uva2ka(pde_t *, char *):&#160;vm.c'],['../vm_8c.html#adefebae1abb3b54fd04d6d4858e7735b',1,'uva2ka(pde_t *pgdir, char *uva):&#160;vm.c']]]
];
