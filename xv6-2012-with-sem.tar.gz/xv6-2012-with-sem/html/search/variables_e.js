var searchData=
[
  ['oemlength',['oemlength',['../structmpconf.html#a1ceb9c0f37d610f220e21ff80705be9c',1,'mpconf']]],
  ['oemtable',['oemtable',['../structmpconf.html#a4a32c8dcc1dc530dd624029c57e7cc5c',1,'mpconf']]],
  ['oesp',['oesp',['../structtrapframe.html#a2fe573b67842f4aaa53302d128ac3ef3',1,'trapframe']]],
  ['off',['off',['../structproghdr.html#a1aeb2e4b0cfd549f8fb46fb7e08f7e3e',1,'proghdr::off()'],['../structfile.html#a1aeb2e4b0cfd549f8fb46fb7e08f7e3e',1,'file::off()']]],
  ['off_5f15_5f0',['off_15_0',['../structgatedesc.html#a0bf2673f8a3b3345556cc583c08bfcbf',1,'gatedesc']]],
  ['off_5f31_5f16',['off_31_16',['../structgatedesc.html#acda895cddc31853ba2be2ca38f9fc106',1,'gatedesc']]],
  ['ofile',['ofile',['../structproc.html#a86c51eb2e4daa425944e034bfad64fb8',1,'proc']]]
];
