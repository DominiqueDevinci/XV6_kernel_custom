var searchData=
[
  ['pde_5ft',['pde_t',['../types_8h.html#ac131849542282b2c95dfeaf1f26dc010',1,'types.h']]],
  ['pte_5ft',['pte_t',['../mmu_8h.html#ab23e75f764f8314a83eaff23508c2ae5',1,'mmu.h']]]
];
