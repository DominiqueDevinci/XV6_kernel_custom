var searchData=
[
  ['acquire',['acquire',['../defs_8h.html#afe4ef8638f1ecb962a6e67fb086ee3b8',1,'acquire(struct spinlock *):&#160;spinlock.c'],['../spinlock_8c.html#aed377f16a085b00de3a4b32392adbdfb',1,'acquire(struct spinlock *lk):&#160;spinlock.c']]],
  ['addr',['addr',['../structmpioapic.html#aab4c2e8e264b16f9babb746d5e7250d5',1,'mpioapic']]],
  ['addrs',['addrs',['../structinode.html#a94905615a8f79fd11b8f500e1bbee16d',1,'inode::addrs()'],['../structdinode.html#a94905615a8f79fd11b8f500e1bbee16d',1,'dinode::addrs()']]],
  ['align',['align',['../structproghdr.html#a8a93f1094c7ddc65184ffb84a9059862',1,'proghdr::align()'],['../umalloc_8c.html#aa508dd61e627680e57643837d292d89f',1,'Align():&#160;umalloc.c']]],
  ['allocuvm',['allocuvm',['../defs_8h.html#a67f50b6f85756f02b5acdcb084d51b9f',1,'allocuvm(pde_t *, uint, uint):&#160;vm.c'],['../vm_8c.html#afea0f0a82a9f9c7aae26f90b5e0836c6',1,'allocuvm(pde_t *pgdir, uint oldsz, uint newsz):&#160;vm.c']]],
  ['alt',['ALT',['../kbd_8h.html#a9d8a33b1a8b82b9913a0ba70438d45be',1,'kbd.h']]],
  ['apicid',['apicid',['../structmpproc.html#a6522b1dc7ec7c8888fb39b08b723bb9b',1,'mpproc']]],
  ['apicno',['apicno',['../structmpioapic.html#ad5298ed5a85376e373300bfe473b5ceb',1,'mpioapic']]],
  ['argint',['argint',['../defs_8h.html#a75bc8d8c7ea0b4b39d4f470e18e0dba7',1,'argint(int, int *):&#160;syscall.c'],['../syscall_8c.html#ade56ef2176f85cd61e7b91b400e7d4d3',1,'argint(int n, int *ip):&#160;syscall.c']]],
  ['argptr',['argptr',['../defs_8h.html#a05c7464938c27eb91540c06ec6137f26',1,'argptr(int, char **, int):&#160;syscall.c'],['../syscall_8c.html#a6ade9205d1f46b759cf93b60513a3421',1,'argptr(int n, char **pp, int size):&#160;syscall.c']]],
  ['args',['args',['../structgatedesc.html#a69a56280915744f111d56afba8b9bbe5',1,'gatedesc']]],
  ['argstr',['argstr',['../defs_8h.html#afc00cb2e6a06b1021f3d82fa4d0eff07',1,'argstr(int, char **):&#160;syscall.c'],['../syscall_8c.html#a662eedd65f3e2165093842b80e3bc024',1,'argstr(int n, char **pp):&#160;syscall.c']]],
  ['argv',['argv',['../structexeccmd.html#aa5d608d354aee96f33c2fdca9a819305',1,'execcmd::argv()'],['../init_8c.html#abd1a2cf54950f450187ef24c1cdcac0c',1,'argv():&#160;init.c']]],
  ['asm',['asm',['../proc_8h.html#a878a634b88f305d27996e9c976dd76c3',1,'asm(&quot;%gs:0&quot;):&#160;proc.h'],['../proc_8h.html#a6424715dee020940c16737056af70edf',1,'asm(&quot;%gs:4&quot;):&#160;proc.h']]],
  ['asm_2eh',['asm.h',['../asm_8h.html',1,'']]],
  ['assert',['ASSERT',['../lapic_8c.html#af343b20373ba49a92fce523e948f2ab3',1,'lapic.c']]],
  ['atoi',['atoi',['../ulib_8c.html#a30670a60464f77af17dfb353353d6df8',1,'atoi(const char *s):&#160;ulib.c'],['../user_8h.html#a4e157d18591ba54c92e4da99a3d1ccae',1,'atoi(const char *):&#160;ulib.c']]],
  ['avl',['avl',['../structsegdesc.html#a3fe31ffafb8c060bbfce5cc88bc4a7c3',1,'segdesc']]]
];
