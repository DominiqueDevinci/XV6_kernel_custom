var searchData=
[
  ['uartinit',['uartinit',['../defs_8h.html#a79fa7b73d0d61fdd15d30768a395437d',1,'uartinit(void):&#160;uart.c'],['../uart_8c.html#a79fa7b73d0d61fdd15d30768a395437d',1,'uartinit(void):&#160;uart.c']]],
  ['uartintr',['uartintr',['../defs_8h.html#aa64047002b0e84e2611ebf7dc46b7c99',1,'uartintr(void):&#160;uart.c'],['../uart_8c.html#aa64047002b0e84e2611ebf7dc46b7c99',1,'uartintr(void):&#160;uart.c']]],
  ['uartputc',['uartputc',['../defs_8h.html#a571626618a1f05ff6854802e936845d6',1,'uartputc(int):&#160;uart.c'],['../uart_8c.html#a55840fa098ac21df6535d6ac91956d07',1,'uartputc(int c):&#160;uart.c']]],
  ['unlink',['unlink',['../user_8h.html#a65a95f51eb9a357f7bef0ebc501b1983',1,'user.h']]],
  ['unlinkread',['unlinkread',['../usertests_8c.html#a3331ced6fb67502a2e5277260d4f5aec',1,'usertests.c']]],
  ['uptime',['uptime',['../user_8h.html#ab637d1dd2fecad1cb0c91a42597a8dbc',1,'user.h']]],
  ['userinit',['userinit',['../defs_8h.html#a81c8a6a0cae413bc81aa223f7f7b7205',1,'userinit(void):&#160;proc.c'],['../proc_8c.html#a81c8a6a0cae413bc81aa223f7f7b7205',1,'userinit(void):&#160;proc.c']]],
  ['uva2ka',['uva2ka',['../defs_8h.html#adcf8d57f1ee45c47df3f63a950f53143',1,'uva2ka(pde_t *, char *):&#160;vm.c'],['../vm_8c.html#adefebae1abb3b54fd04d6d4858e7735b',1,'uva2ka(pde_t *pgdir, char *uva):&#160;vm.c']]]
];
