var searchData=
[
  ['w',['w',['../console_8c.html#afdeff54db9a334718662b709641fdfe1',1,'console.c']]],
  ['wait',['wait',['../defs_8h.html#af6f31822f7e737b4e414bdac1ccb59a4',1,'wait(void):&#160;proc.c'],['../proc_8c.html#af6f31822f7e737b4e414bdac1ccb59a4',1,'wait(void):&#160;proc.c'],['../user_8h.html#af6f31822f7e737b4e414bdac1ccb59a4',1,'wait(void):&#160;proc.c']]],
  ['waitdisk',['waitdisk',['../bootmain_8c.html#a63222d4a07c38c198de5bd116a001935',1,'bootmain.c']]],
  ['wakeup',['wakeup',['../defs_8h.html#a245b56417239f499389b2e806bd99254',1,'wakeup(void *):&#160;proc.c'],['../proc_8c.html#a4a34d9f03e436cfa09b88f735f6ee952',1,'wakeup(void *chan):&#160;proc.c']]],
  ['wc',['wc',['../wc_8c.html#a4f21d23f0e3167f510b9f393b185751c',1,'wc.c']]],
  ['wc_2ec',['wc.c',['../wc_8c.html',1,'']]],
  ['whitespace',['whitespace',['../sh_8c.html#ab8474337bbc7c7d316b75b5c00d79947',1,'sh.c']]],
  ['winode',['winode',['../mkfs_8c.html#a2540c48cea7dc865909cfb3f8450a887',1,'mkfs.c']]],
  ['writable',['writable',['../structfile.html#a46baf97119b7f82a588f0f603451da62',1,'file']]],
  ['write',['write',['../structdevsw.html#a116cc993ece86c6fa11057b78786cfe2',1,'devsw::write()'],['../user_8h.html#a894862d36b7a203a88a0c1ab835b8230',1,'write():&#160;user.h']]],
  ['writei',['writei',['../defs_8h.html#a515876d4653cefef4732806ef7f2833f',1,'writei(struct inode *, char *, uint, uint):&#160;fs.c'],['../fs_8c.html#a15858f4d8a4cc1def3d84d03c312836b',1,'writei(struct inode *ip, char *src, uint off, uint n):&#160;fs.c']]],
  ['writeopen',['writeopen',['../structpipe.html#ae4254bf1d401e056beef1e2630c334e5',1,'pipe']]],
  ['writetest',['writetest',['../usertests_8c.html#a3a007a46ea6310b39a233e45d439f11a',1,'usertests.c']]],
  ['writetest1',['writetest1',['../usertests_8c.html#a48ac3cbd37dcf4c4e08b0572b3a0e9f3',1,'usertests.c']]],
  ['wsect',['wsect',['../mkfs_8c.html#ac62d827d836d1807e4d6f365f32348bb',1,'mkfs.c']]]
];
