var searchData=
[
  ['redir',['REDIR',['../sh_8c.html#ae1749b6682612a761fc83e79c38386b1',1,'sh.c']]],
  ['reg_5fid',['REG_ID',['../ioapic_8c.html#a91339a8293cb53b81407c016bc41e2b1',1,'ioapic.c']]],
  ['reg_5ftable',['REG_TABLE',['../ioapic_8c.html#ad31b206e97e5e8cc5c70f8713669b27f',1,'ioapic.c']]],
  ['reg_5fver',['REG_VER',['../ioapic_8c.html#ac56cc95ec46071699b119b24d6d808f9',1,'ioapic.c']]],
  ['rootdev',['ROOTDEV',['../param_8h.html#ae9ce6b24fe2aae59ff60b469c35febbc',1,'param.h']]],
  ['rootino',['ROOTINO',['../fs_8h.html#a22c8ea96d09283ed6496347806cc72a0',1,'fs.h']]]
];
