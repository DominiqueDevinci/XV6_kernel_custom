var fcntl_8h =
[
    [ "O_CREATE", "fcntl_8h.html#ab40a23079c3b9a7e25ffdc8108c7fb02", null ],
    [ "O_RDONLY", "fcntl_8h.html#a7a68c9ffaac7dbcd652225dd7c06a54b", null ],
    [ "O_RDWR", "fcntl_8h.html#abb0586253488ee61072b73557eeb873b", null ],
    [ "O_WRONLY", "fcntl_8h.html#a11b644a8526139c4cc1850dac1271ced", null ]
];