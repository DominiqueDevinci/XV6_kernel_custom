var structproghdr =
[
    [ "align", "structproghdr.html#a8a93f1094c7ddc65184ffb84a9059862", null ],
    [ "filesz", "structproghdr.html#af68648ec9784a595235d016a78d4e443", null ],
    [ "flags", "structproghdr.html#a660f9db871d26052904976a8bfe8432d", null ],
    [ "memsz", "structproghdr.html#adda66e6aa36c4d480d9a96db0653f1c0", null ],
    [ "off", "structproghdr.html#a1aeb2e4b0cfd549f8fb46fb7e08f7e3e", null ],
    [ "paddr", "structproghdr.html#a7383e3ef8c57b24150c4894c30fbded5", null ],
    [ "type", "structproghdr.html#a4e4020c6e82bee6562d5bc3c1657cafe", null ],
    [ "vaddr", "structproghdr.html#aa974042c9a1f07947e76c236ba11fd96", null ]
];