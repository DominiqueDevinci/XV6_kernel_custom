var bio_8c =
[
    [ "binit", "bio_8c.html#a53cca0ddc98c5f1de37124eca2575a59", null ],
    [ "bread", "bio_8c.html#ac09898fdd6868e88ff35f498fa6ef52f", null ],
    [ "brelse", "bio_8c.html#ab5335aeb503731104314321a78a6d727", null ],
    [ "bwrite", "bio_8c.html#a63c899c13b176ddf80064d32225e1298", null ],
    [ "bcache", "bio_8c.html#a8c840c340a1233a78bdb2af607bbbcfc", null ],
    [ "buf", "bio_8c.html#a72ee90c61d41547b10a533c219e081c6", null ],
    [ "head", "bio_8c.html#aa6e692c16f1b909f5cb2a1832cf43430", null ],
    [ "lock", "bio_8c.html#ab28e82cd5dda7d960095706a3ea20572", null ]
];