var structdinode =
[
    [ "addrs", "structdinode.html#a94905615a8f79fd11b8f500e1bbee16d", null ],
    [ "major", "structdinode.html#abe2b53edb36f3d674f052ab7254d4a3e", null ],
    [ "minor", "structdinode.html#adb75a8841fbdda3cb4f2373edac4f1dc", null ],
    [ "nlink", "structdinode.html#aa7e1ed70907ed9a2fc9c9a7c24cd0d4d", null ],
    [ "size", "structdinode.html#a22d26304a3b3aca97e6311f6939dd1bf", null ],
    [ "type", "structdinode.html#acd579dfd50a9ea905ca697ed8707bf3b", null ]
];