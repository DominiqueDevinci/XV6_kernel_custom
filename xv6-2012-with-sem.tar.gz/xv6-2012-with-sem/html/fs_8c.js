var fs_8c =
[
    [ "min", "fs_8c.html#ac6afabdc09a49a433ee19d8a9486056d", null ],
    [ "dirlink", "fs_8c.html#a69a135a0e8a06d9f306d77ebc0c1f7a0", null ],
    [ "dirlookup", "fs_8c.html#aa182c62fade7a0bae9408830d5e06d4f", null ],
    [ "ialloc", "fs_8c.html#adb360ce0b70a32d19d089fba4cd91293", null ],
    [ "idup", "fs_8c.html#a6b41577cc09b2a009be8f84bfb500079", null ],
    [ "iinit", "fs_8c.html#a508e2b44186d5b3997a1564fe5a6c2d9", null ],
    [ "ilock", "fs_8c.html#aed28187406d84a3aa71f10c6235a03ec", null ],
    [ "iput", "fs_8c.html#ab3c447f135c68e4c3c1f8d5866f6e77b", null ],
    [ "iunlock", "fs_8c.html#ae4e29916219b9293b37f9c34220694fe", null ],
    [ "iunlockput", "fs_8c.html#a207b3008bae35596c55ec7c4fc6875eb", null ],
    [ "iupdate", "fs_8c.html#a7220afa8e5f4bea540eb95879ea7df6e", null ],
    [ "namecmp", "fs_8c.html#ae74f6e5b19a4e7f3e72807ee67141819", null ],
    [ "namei", "fs_8c.html#a9baba030d5bc6e9e20cf8b7d181edf35", null ],
    [ "nameiparent", "fs_8c.html#a5a987ca4f8ffd579b96a8b9a60e61a7c", null ],
    [ "readi", "fs_8c.html#a3aba1fa9f6789d09356aec5b96d91fa8", null ],
    [ "readsb", "fs_8c.html#aff0080b2133027be2e525ca088b40e78", null ],
    [ "stati", "fs_8c.html#a4ccff0bd4d9802e709d0af8d71a59861", null ],
    [ "writei", "fs_8c.html#a15858f4d8a4cc1def3d84d03c312836b", null ],
    [ "icache", "fs_8c.html#a1fbfdebf96af7ed1f992e387cba059b3", null ],
    [ "inode", "fs_8c.html#a6baaf26dd83b71b8d684c5d54a709e31", null ],
    [ "lock", "fs_8c.html#ab28e82cd5dda7d960095706a3ea20572", null ]
];