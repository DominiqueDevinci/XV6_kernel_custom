var structlogheader =
[
    [ "n", "structlogheader.html#a76f11d9a0a47b94f72c2d0e77fb32240", null ],
    [ "sector", "structlogheader.html#a7227c34c5d6735d036dc8e7b4e8fec9a", null ]
];