var ls_8c =
[
    [ "fmtname", "ls_8c.html#a955d63056d4df92f4e7f63a52762720d", null ],
    [ "ls", "ls_8c.html#a0dd2caa6531a27dcd755c46e814b63af", null ],
    [ "main", "ls_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ]
];